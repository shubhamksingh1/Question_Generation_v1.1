class colors:
	
	def color_codes(self, index):
		codes = ['\033[0m', '\033[91m', '\033[92m']
		return codes[index]
